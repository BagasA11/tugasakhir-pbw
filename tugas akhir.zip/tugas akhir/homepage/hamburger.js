var Menu = document.querySelector(".menuList");
function menu(){
    Menu.classList.toggle('show');
}