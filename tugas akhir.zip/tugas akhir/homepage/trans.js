var list = document.querySelector('#transaksi');

function transaksi(){
    list.classList.toggle('transActive');
}